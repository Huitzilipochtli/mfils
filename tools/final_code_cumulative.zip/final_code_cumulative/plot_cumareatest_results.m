function [x0 y0] = plot_cumareatest_results(at, xt, yt, critp, lw, period, holetx,holety,name)

%Inputs:
% xt - a MxN cell array containing the x-coordinates of all pathways.
% M denotes the number of pathways and N denotes the number of
% pointwise significance levels that were input into the
% wt_areawise routine. The default value of N is 9.
% xt - Time-coordinates of all pathways.
% yt - Same as xt but for the scale-coordinates of all pathways.

% at - A MxN matrix of normalized areas, where the rows correspond
% to the distinct geometric pathways and the columns refer to the
% significance level at which each of the pathway elements
% exist. The first column consists of the normalized areas of the
% largest elements of the M geometric pathways.

% pvals - A MxN matrix of p-values, where the rows correspond to
% distinct geometric pathways and the columns refer to the
% pointwise significance level at which each of the pathway elements
% exist. The first column consists of the p-values of the
% largest elements of the M geometric pathways.

% critp - the significance level of the test. The default is 0.05.

% lw - linewidth to indicate significant pathway elements on
% figure

% period - a vector array of Fourier periods

% holetx - cell array of time-coordinates for all holes at every
% pointwise significance level.

% holety - cell array of scale-coordinates for all holes at every
% pointwise significance level.

%Outputs:
% x0 and x0 are the union of all significant pathways whose
% p-values are less than critp

% default null distribution, anull, for Morlet wavelet for alphas = 0.82:.02:0.99
if(strcmp('Morlet',name))
    load  'nulldis_cumulativetest_morlet';
elseif(strcmp('Paul',name))
    load  'nulldis_cumulativetest_paul';
else
    load  'nulldis_cumulativetest_dog';
end

at(isnan(at)) = 0;
csum = cumsum(at,2);


for j=1:length(at(1, :))-1
    
    pvals(:, j) = calculate_pvalue_geo(csum(:,j),anull);
end

% get significant pathways
[x0 y0 xcum ycum csum] = getpathway_element(at, xt, yt, pvals, critp);



for jj=1:length(ycum)
    plot(xcum{jj} , log2(period(ycum{jj})),'k','linewidth',lw);
end


xh0 = NaN;
yh0 = NaN;


% find the union of all holes located in signifcant pathway elements

for jj = 1:length(holety)
    
    [dx dy] =   polybool('intersection',x0, y0,holetx{jj}, holety{jj});
    
    if(length(dx)>0)
        
        [dx dy] =   polybool('union',xh0, yh0,holetx{jj}, holety{jj});
        xh0 = dx;
        yh0 = dy;
        
    end
    
end


[holetx holety] = polysplit(xh0, yh0);

for jj=1:length(holety)
    
    ytemp = holety{jj};
    ytemp(ytemp > length(period)) = length(period);
    holety{jj} = ytemp;
    
    if(~isnan(holety{jj}))
        
        plot(holetx{jj} , log2(period(holety{jj})),'k','linewidth',lw);
        
    end
end
    
        
  
  
  
end

