function [newx, newy] = logbin(xdata, ydata, numint)
%function [newx, newy] = logbin(xdata, ydata, numint)
% this function bins vectors so that they are plotted with even spacing on a log-scale...
% USE: [x,y] = logbin(xdata, ydata, numint);
% DKF 040126
% Stolen and modified, 071210 GMW.

logmin = log(min(xdata)); logmax = log(max(xdata));
interval = abs(logmax - logmin)/numint;

intvec = exp(logmin + interval.*(0:numint)');

newx = []; newy = [];
for j = 1:numint
    a = find(xdata>intvec(j) & xdata<(intvec(j) + intvec(j+1)));
    x = nanmean(xdata(a));
    newx = [newx; x];
    y = nanmean(ydata(a,:),1);
    newy = [newy; y];
end

