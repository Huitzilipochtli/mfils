function varargout=wt_areawise(d,varargin)
%% Continous Wavelet Transform
% Creates a figure of wavelet power in units of
% normalized variance.
%
% USAGE: [wave,period,scale,coi,sig95]=wt(d[,params])
% 
% d: a time series
% wave: the wavelet transform of d
% period: a vector of "Fourier" periods associated with wave
% scale: a vector of wavelet scales associated with wave
% coi: the cone of influence
% alpahc: significance level of cumulative areawise test
% alphas: array of pointwise significance levels

%
% Settings: Pad: pad the time series with zeros? 
% .         Dj: Octaves per scale (default: '1/12')
% .         S0: Minimum scale
% .         J1: Total number of scales
% .         Mother: Mother wavelet (default 'morlet')
% .         MaxScale: An easier way of specifying J1
% .         MakeFigure: Make a figure or simply return the output.
% .         BlackandWhite: Create black and white figures
% .         AR1: the ar1 coefficient of the series 
% .              (default='auto' using a naive ar1 estimator. See ar1nv.m)
%
% Settings can also be specified using abbreviations. e.g. ms=MaxScale.
% For detailed help on some parameters type help wavelet.
%
%
% Example:
%      wt([0:200;sin(0:200)],'dj',1/20,'bw','maxscale',32)
%



%----------------------------------------------------------------------------------

% statements from orginal code written by A. Grintsted 

% Please acknowledge the use of this software in any publications:
%   "Crosswavelet and wavelet coherence software were provided by
%   A. Grinsted."
%
% (C) Aslak Grinsted 2002-2004
%
% http://www.pol.ac.uk/home/research/waveletcoherence/

%   Copyright (C) 2002-2004, Aslak Grinsted
%   This software may be used, copied, or redistributed as long as it is not
%   sold and this copyright notice is reproduced on each copy made.  This
%   routine is provided as is without any express or implied warranties
%   whatsoever.
%----------------------------------------------------------------------------

% needs:
      % requires geometric significance testing software available at
      % http://www.mathworks.com/matlabcentral/fileexchange/50110-geometric-and-topological-methods-for-wavelet-analysis.
      % Please see code for information and other external software needed
      % to run wt_areawise. 

% ------validate and reformat timeseries.


[d,dt]=formatts(d);

n=size(d,1);
sigma2=var(d(:,2));



%----------default arguments for the wavelet transform-----------
Args=struct('Pad',1,...      % pad the time series with zeroes (recommended)
            'Dj',1/12, ...    % this will do 12 sub-octaves per octave
            'S0',2*dt,...    % this says start at a scale of 2 years
            'J1',[],...
            'Mother','Morlet', ...
            'MaxScale',[],...   %a more simple way to specify J1
            'MakeFigure',(nargout==0),...
            'BlackandWhite',0,...
            'alphas', 0.82:0.02:0.98,...
            'alphac', 0.05,...
            'AR1','auto');
Args=parseArgs(varargin,Args,{'BlackandWhite'});
if isempty(Args.J1)
    if isempty(Args.MaxScale)
        Args.MaxScale=(n*.17)*2*dt; %automaxscale
    end
    Args.J1=round(log2(Args.MaxScale/Args.S0)/Args.Dj);
end

if strcmpi(Args.AR1,'auto')
    Args.AR1=ar1nv(d(:,2));
    if any(isnan(Args.AR1))
        error('Automatic AR1 estimation failed. Specify it manually (use arcov or arburg).')
    end
end



%----------------::::::::---------- Analyze: ---------:::::::::::::-----------------


% pre-calculated null distributions only valid for these pointwise significance
% levels 



[wave,period,scale,coi] = wavelet(d(:, 2),dt,Args.Pad,Args.Dj,Args.S0,Args.J1,Args.Mother);

t=d(:,1);
power = (abs(wave)).^2 ;        % compute wavelet power spectrum



for ii=1:length(Args.alphas)
    signif = wave_signif(1.0,dt,scale,0,Args.AR1,Args.alphas(ii),-1,Args.Mother);
    sig(:,:,ii) = (signif')*(ones(1,n));  % expand signif --> (J+1)x(N) array
    sig(:,:,ii) = power ./ (sigma2.*sig(:,:,ii));
end

if(n>=500)
    K = floor(n/500);
    Q = floor(n/K);
    T(:,2) =  (1:K)*Q;
    T(:,1)  =  (0:K-1)*Q;
    T(end,2) = n;
else
    T(1,1)  =  0; 
    T(1,2) = n;
    K = 1; 
end

% Find geometric pathways in time slices of the wavelet domain for faster
% computation. K is the number of slices and if K = 1, then the entire 
% wavelet domain is used at once. 

for k=1:K
    
    for i=1:length(Args.alphas)
        [x{i} y{i} xh{i} yh{i} narea{i}] = polydivide(sig(:,:,i),T(k,1),T(k,2),scale);
    end
    
    [xt yt xpatch ypatch at holetx holety] = createpathways(x, y, xh, yh,narea);

    if(k==1)
      anew = at;  
      xnew = xt; 
      ynew = yt; 
      xhnew = holetx; 
      yhnew = holety;
    else
      anew = vertcat(anew,at);  
      xnew = vertcat(xnew,xt);  
      ynew = vertcat(ynew,yt); 
      xhnew = vertcat(xhnew,holetx);  
      yhnew = vertcat(yhnew,holety); 
      
    end
    
    
end


Yticks = 2.^(fix(log2(min(period))):fix(log2(max(period))));

if Args.MakeFigure

    if Args.BlackandWhite
       
        
        levels = [0.25,0.5,1,2,4,8,16] ;
        
        [x0 y0] = plot_cumareatest_results(anew, xnew, ynew, Args.alphac, 3, period,xhnew, yhnew, Args.Mother);
      
        cout(1,:)=2.^cout(1,:);

        HCB=colorbarf;
        barylbls=rats([0 levels 0]');
        barylbls([1 end],:)=' ';
        barylbls(:,all(barylbls==' ',1))=[];
        set(HCB,'yticklabel',barylbls);
        cmap=(1:-.01:.5)'*.9;
        cmap(:,2:3)=cmap(:,[1 1]);
        cmap(:,1:2)=cmap(:,1:2)*.8;
        colormap(cmap);
        set(gca,'YLim',log2([min(period),max(period)]), ...
            'YDir','reverse', ...
            'YTick',log2(Yticks(:)), ...
            'YTickLabel',num2str(Yticks'), ...
            'layer','top')
        xlabel('Time')
        ylabel('Period')
        hold on

    
         
        hcoi=fill([t([1 1:end end])],log2([period(end) coi period(end)]),'r')
        set(hcoi,'alphadatamapping','direct','facealpha',.3)

        hold off
    else
        H=imagesc(t,log2(period),log2(abs(power/sigma2)));%#ok,log2(levels));  %*** or use 'contourfill'
        hold on
        
        [x0 y0] = plot_cumareatest_results(anew, xnew, ynew, Args.alphac, 3, period, xhnew, yhnew, Args.Mother);
        
        clim=get(gca,'clim'); %center color limits around log2(1)=0
        clim=[-1 1]*max(clim(2),3);
        clim = [-4.32 4.32];
        set(gca,'clim',clim)
   
        HCB = colorbar;
        set(HCB,'ytick',-7:7);
        barylbls=rats(2.^(get(HCB,'ytick')'));
        barylbls([1 end],:)=' ';
        barylbls(:,all(barylbls==' ',1))=[];
        set(HCB,'yticklabel',barylbls);
       
        
        set(gca,'YLim',log2([min(period),max(period)]), ...
            'YDir','reverse', ...
            'YTick',log2(Yticks(:)), ...
            'YTickLabel',num2str(Yticks'), ...
            'layer','top')
        xlabel('Time');
        ylabel('Period');
        hold on

        
        
      
        tt=[t([1 1])-dt*.5;t;t([end end])+dt*.5];
        hcoi=fill(tt,log2([period([end 1]) coi period([1 end])]),'w');
        set(hcoi,'alphadatamapping','direct','facealpha',.5);

        hold off
    end
    set(gca,'box','on','layer','top');
end
varargout={wave,period,scale,coi,sig anew};
varargout=varargout(1:nargout);


