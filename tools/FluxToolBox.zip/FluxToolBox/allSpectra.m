function S = allSpectra(w,x,F,nbin,plotSpectra)
% function S = allSpectra(w,x,F,nbin,plotSpectra)
% Calls subroutines to calculate spectra and cospectra (i.e. fourier transforms) of data used in
% eddy covariance calculations.
% IMPORTANT NOTE: input data w and x must be constantly spaced in time and cannot contain NaNs!
%
% INPUTS:
% w: vertical wind speed
% x: scalar vector (e.g. concentration, mixing ratio, etc).
% F: frequency of observations, Hz.
% nbin: number of bins for log-averaging spectra.
% plotSpectra: flag for plotting spectra. 0=no, 1=yes.
%
% OUTPUTS:
% S: a structure containing all of the computed spectra.
%       f:      frequency, Hz
%       psdx:   x power spectrum
%       psdxn:  variance-normalized x power spectrum
%       ogx:    x ogive 
%       psdw:   w power spectrum
%       psdwn:  variance-normalized w power spectrum
%       ogw:    w ogive
%       co:     w-x cospectrum
%       con:    covariance-normalized w-x cospectrum
%       ogwx:   w-x ogive
%
% 20130921 GMW

%subtract means
x = x - nanmean(x);
w = w - nanmean(w);

%% power spectra x
[f, psdx, psdxn] = spectra(F,x);
ogx = ogive(f,psdx);

[fb, psdxnb] = logbin(f, psdxn, nbin);
f53 = f.^(-5/3)./f(1).^(-5/3).*psdxn(1);

if plotSpectra
    figure
    loglog(f,psdxn,'c-')
    hold on
    loglog(fb,psdxnb,'b-','lineWidth',3)
    loglog(f,f53,'k--')
    xlabel('Frequency (Hz)')
    ylabel('x Spectral Power')
    legend('Data','Avg','-5/3')
    
    figure
    semilogx(f,psdxn.*f,'c-')
    hold on
    semilogx(fb,psdxnb.*fb,'b-','lineWidth',3)
    xlabel('Frequency (Hz)')
    ylabel('SP_x*F')
    
    figure
    semilogx(f,ogx,'b-')
    xlabel('Frequency (Hz)')
    ylabel('x Ogive')
end

%% power spectra w
[f psdw psdwn] = spectra(F,w);
ogw = ogive(f,psdw);

[fb, psdwnb] = logbin(f, psdwn, nbin);
f53 = f.^(-5/3)./f(1).^(-5/3).*psdwn(1);

if plotSpectra
    figure
    loglog(f,psdwn,'c-')
    hold on
    loglog(fb,psdwnb,'b-','lineWidth',3)
    loglog(f,f53,'k--')
    xlabel('Frequency (Hz)')
    ylabel('w Spectral Power')
    legend('Data','Avg','-5/3')
    
    figure
    semilogx(f,psdwn.*f,'c-')
    hold on
    semilogx(fb,psdwnb.*fb,'b-','lineWidth',3)
    xlabel('Frequency (Hz)')
    ylabel('SP_w*F')
    
    figure
    semilogx(f,ogw,'b-')
    xlabel('Frequency (Hz)')
    ylabel('w Ogive')
end

%% cospectra
[f co con] = cospectra(F,w,x);
ogwx = ogive(f,co);

[fb, conb] = logbin(f, con, nbin);
f53 = abs(f.^(-5/3)./f(1).^(-5/3).*con(1));

%separate positive and negative
pos = con>0;
neg = con<=0;

posb = conb>0;
negb = conb<=0;

if plotSpectra
    figure
    loglog(f(pos),con(pos),'c-')
    hold on
    loglog(fb(posb),conb(posb),'bo','lineWidth',2)
    loglog(fb(negb),-conb(negb),'rd','lineWidth',2)
    loglog(f,f53,'k--')
    xlabel('Frequency (Hz)')
    ylabel('w-x Spectral Power')
    legend('Data','+ Avg','- Avg','-5/3')
    
    figure
    semilogx(f,con.*f,'c-')
    hold on
    semilogx(fb,conb.*fb,'b-','lineWidth',3)
    xlabel('Frequency (Hz)')
    ylabel('SP_w_-_x*F')
    
    figure
    semilogx(f,ogwx,'b-')
    xlabel('Frequency (Hz)')
    ylabel('w-x Ogive')
end

%% Accumulate structure
S.f = f;

S.psdx = psdx;
S.psdxn = psdxn;
S.ogx = ogx;

S.psdw = psdw;
S.psdwn = psdwn;
S.ogw = ogw;

S.co = co;
S.con = con;
S.ogwx = ogwx;

