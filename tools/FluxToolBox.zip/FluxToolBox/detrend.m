function x_dt = detrend(x,t,trendType,frameSize,plotMe)
% function x_dt = detrend(x,t,trendType,frameSize,plotMe)
% Removes a trend from a piece of data. Meant to be used with ECFluxToolBox.
%
% INPUTS:
% x: variable to be detrended. 1-D vector.
% t: time vector for x.
% trendType: string specifier for detrending. options are "mean", "linear" and "smooth."
% frameSize: number of points to use for smoothing. Default is 100.
% plotMe: flag for generating plots. Default is 0 (no).
%
% OUTPUTS:
% x_dt is x with the trend subtracted.
%
% 20130915 GMW

%defaults
if nargin<5
    plotMe = 0;
end

if nargin<4
    frameSize = 100;
end

%calculate trends
xmean = nanmean(x).*ones(size(x)); %mean
fit = nanpolyfit(t,x,1);
xlin = polyval(fit,t); %linear
xsmooth = smooth(x,frameSize,'mean'); %smooth

% detrend
switch trendType
    case 'mean'
        x_dt = x - xmean;
    case 'linear'
        x_dt = x - xlin;
    case 'smooth'
        x_dt = x - xsmooth;
    otherwise
        error(['detrend: trendType "' trendType '" not recognized. '...
            'Valid values are "mean", "linear" and "smooth".'])
end

%make plots if desired
if plotMe
    figure
    hold all
    plot(t,x,'c-',...
        t,xmean,'k-',...
        t,xlin,'r-')
    plot(t,xsmooth,'b-','LineWidth',4)
    xlabel('Time')
    ylabel('x')
    legend('Data','Mean','Linear','Smooth')
    box on
    
    figure
    plot(t,x_dt,'b-')
    xlabel('Time')
    ylabel('x detrended')
end


