function [f psdx psdxnorm] = spectra(Fs,x)
%function [f psdx psdxnorm] = spectra(Fs,x)
%calculates spectrum and power spectrum for a data time series.
%INPUTS:
%x: data vector as a column
%Fs: Sampling Frequency in Hz
%OUTPUTS:
%f: frequency vector for spectra
%psdx: power spectral density of x
%psdxnorm: psdx normalized to total variance
%Lifted from Ian's spec_all.m file.
%071128 GMW

x = x - nanmean(x);

%%%%%SET FREQEUNCY ACCESS AND SAMPLING RATE/TIME%%%%%
N=length(x);
tm=N/Fs;%sampling time
df=1/tm;
f=0:df:Fs; f=f(:);
 
%%%%%CALCULATE FOURIER TRANSFORMS AND SPECTRA%%%%%
xx = fft(x,N);%spectrum

pxx = xx.*conj(xx)/N^2;%power spectrum
psdx = pxx./df;%power spectral density

% Fold over spectrum
di2=floor(length(psdx)/2);
psdx=2.*psdx(2:di2);
f=f(2:di2);

%%%%%COMPARE VARIANCES%%%%%
varx=(std(x))^2;
var2x=sum(psdx)*df;
reldif=abs(varx-var2x)/varx;
if reldif > .01
   warning(['Relative difference between calculated and psd-estimated '...
       'variance is:  ', num2str(reldif*100), ' %'])
end

%normalize by variance
psdxnorm = psdx./var2x;

