function F = ECFlux(data,options)
% function F = ECFlux(data,options)
% Runs a series of calculations to derive a flux using the eddy covariance method.
% The order of operations is as follows:
% 1) detrend scalar variable x
% 2) rotate 3-D winds into natural wind coordinate (such that mean cross and vertical wind speeds are 0) 
% 3) lag scalar and vertical wind vectors to optimize covariance
% 4) calculate covariance and exchange velocity
% 5) plot quadrant data
% 6) plot frequency spectra
%
% INPUTS:
% data: structure containing the necessary data. Note that all vectors must be the same length.
%   t: time vector, typically in seconds. Must have constant spacing.
%   x: scalar vector (e.g. concentration)
%   u: horizontal wind speed
%   v: cross-wind speed
%   w: vertical wind speed
% options: structure containing parameters that specify operations and output.
%   xTrendType:      detrending method. valid values are 'mean' (default), 'linear' and 'smooth'. 
%   frameSize:       frame size for trend if 'smooth' is selected. default is 100.
%   thirdRotation:   flag for third wind rotation (to make v'w' = 0). default = 0.
%   plotX:           flag for plotting x data. default is 0.
%   plotW:           flag for plotting wind data. default is 0.
%   plotLag:         flag for lag-covariance plot. default is 0.
%   plotQuad:        flag for quadrant plot. default is 0.
%   plotSpectra:     flag for frequency-spectrum plots. default is 0.
%   nLags:           number of lag points for lag-covariance. default is 100.
%   xLag:            lag to apply to x (if not determined automatically). default is [];
%
% OUTPUTS
% F: a structure containing the following fields:
%   data:   same as data input
%   options: same as options input
%   flux:   eddy covariance flux (w'x')
%   vex:    exchange velocity (w'x'/mean(x))
%   x_dt:   x after detrending
%   x_dtl:  detrended x, lagged to optimize covariance with w
%   u_r:    rotated horizonal wind speed
%   v_r:    rotated cross wind speed
%   w_r:    rotated vertical wind speed
%   angles: structure of wind rotation angles:
%       eta:    rotation angle around the z1 axis
%       theta:  rotation angle around the y1 axis
%       beta:   rotation angle around x2 axis to make mean(w2'v2') = 0.
%   cov_wx: covariance of w' and x' at various lags
%   lags:   # of x lag points relative to w. Corresponds to cov_wx.
%   Sp:     structure containing spectra and cospectra:
%       f:      frequency, Hz
%       psdx:   x power spectrum
%       psdxn:  variance-normalized x power spectrum
%       ogx:    x ogive 
%       psdw:   w power spectrum
%       psdwn:  variance-normalized w power spectrum
%       ogw:    w ogive
%       co:     w-x cospectrum
%       con:    covariance-normalized w-x cospectrum
%       ogwx:   w-x ogive
%
% 20130920 GMW

% assign default options
defaults = {...
   'xTrendType'         'mean';...
   'frameSize'          100;...
   'thirdRotation'      0;...
   'plotX'              0;...
   'plotW'              0;...
   'plotLag'            0;...
   'plotQuad'           0;...
   'plotSpectra'        0;...
   'nLags'              100;...
   'xLag'               [];...
   };

Onames = fieldnames(options);
check = ismember(defaults(:,1),Onames);
imiss = find(~check);
for i=1:length(imiss)
    options.(defaults{imiss,1}) = defaults{imiss,2};
end

% break out structures
struct2var(data)
struct2var(options)
freq = 1./mean(diff(t)); %data frequency, Hz

% detrend x
x_dt = detrend(x,t,xTrendType,frameSize,plotX);

% rotate winds
[u_r,v_r,w_r,angles] = natWindRot(u,v,w,t,thirdRotation,plotW);

% calculate flux and lag
[cov_wx,lags] = lagCov(w_r,x_dt,nLags,plotLag,t);

if isempty(xLag)
    [flux,imax] = max(abs(cov_wx));
    xLag = lags(imax);
    options.xLag = xLag; %replace empty value
    disp(['Best lag is ' num2str(xLag) ' points.'])
else
    flux = cov_wx(lags==xLag);
end
vex = flux./nanmean(x); %exchange velocity
x_dtl = lagVar(x_dt,xLag); %lag x

% more plots
if plotQuad
    quadPlot(w_r,x_dtl);
end

% spectra
w_r(isnan(w_r)) = 0; %there is probably a better way to gap-fill
x_dtl(isnan(x_dtl)) = 0;
nbin = 50; %number of log bins
Sp = allSpectra(w_r,x_dtl,freq,nbin,plotSpectra);

% build output structure
F.data      = data;
F.options   = options;
F.flux      = flux;
F.vex       = vex;
F.x_dt      = x_dt;
F.u_r       = u_r;
F.v_r       = v_r;
F.w_r       = w_r;
F.angles    = angles;
F.cov_wx    = cov_wx;
F.lags      = lags;
F.x_dtl     = x_dtl;
F.Sp        = Sp;

