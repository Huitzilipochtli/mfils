function og = ogive(f,co)
%function og = ogive(f,co)
%calculates an ogive for a cospectrum.
%An ogive is basically a cumulative integral under the cospectrum.
%071128 GMW
%removed for-loop. 090711 GMW

if size(f,2)>1, f=f'; end %turn to columns if necessary
if size(co,2)>1,co=co'; end

f = flipud(f); co = flipud(co); %want to integrate from the high-frequency end downward

df = [0; abs(diff(f))];
og = cumsum(co.*df);

og = flipud(og);

og = og./og(1); %normalize to total covariance

if size(co,2)>1,og=og'; end

