function [f co co_norm] = cospectra(Fs,x,y,pts2lag)
%function [f co co_norm] = cospectra(Fs,x,y)
%calculates cospectrum for two data time series.
%INPUTS:
%x: first data vector as a column
%y: second data vector
%Fs: Sampling Frequency in Hz
%pts2lag: optional input, indicating the number of points to lag y relative to x.
%OUTPUTS:
%f: frequency vector for spectra
%co: cospectral density of x and y
%co_norm: co normalized to total covariance
%Lifted from Ian's spec_all.m file.
%071128 GMW

x = x - nanmean(x);
y = y - nanmean(y);

%lag y vector relative to x and remove resulting nan-filled rows
if nargin==4
    y = lagmatrix(y,pts2lag);
    i=find(isnan(y)); x(i)=[]; y(i)=[];
    clear i
end

%%%%%SET FREQEUNCY ACCESS AND SAMPLING RATE/TIME%%%%%
N=length(x);
tm=N/Fs;%sampling time
df=1/tm;
f=0:df:Fs; f=f(:);
 
%%%%%CALCULATE FOURIER TRANSFORMS AND SPECTRA%%%%%
xx = fft(x,N);%spectrum
yy = fft(y,N);

cross=xx.*conj(yy)/N^2;
cr2=cross/df;

%fold over cospectrum
di2=floor(length(cr2)/2);
co=2*real(cr2(2:di2));
f=f(2:di2);

%%%%%COMPARE COVARIANCES%%%%%
covxy=nanmean(x.*y);
cov2xy=sum(co)*df;
reldif=abs(covxy-cov2xy)/covxy;
% if reldif > .01
%     warning(['Relative difference between calculated and psd-estimated '...
%         'covariance is:  ', num2str(reldif*100), ' %'])
% end

%normalize by variance
co_norm = co./cov2xy;

