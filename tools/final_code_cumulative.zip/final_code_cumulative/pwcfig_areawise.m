% Please acknowledge the use of this software in any publications:
%   "Crosswavelet and wavelet coherence software were provided by
%   A. Grinsted."
%
% (C) Aslak Grinsted 2002-2004
%
% http://www.pol.ac.uk/home/research/waveletcoherence/


% -------------------------------------------------------------------------
%   Copyright (C) 2002-2004, Aslak Grinsted
%   This software may be used, copied, or redistributed as long as it is not
%   sold and this copyright notice is reproduced on each copy made.  This
%   routine is provided as is without any express or implied warranties
%   whatsoever.

   wtcsig = wtcsignif_modified(Args.MonteCarloCount,Args.AR1,dt,length(t)*2,Args.Pad,Args.Dj,Args.S0,Args.J1,Args.Mother,.6,Args.alphas);
   

for ii=1:length(Args.alphas)
    sigtemp = (wtcsig(:,ii))*(ones(1,n));
    sig(:,:,ii) = Rsq./sigtemp;    
end


if(n>=500)
    K = floor(n/500);
    Q = floor(n/K);
    T(:,2) =  (1:K)*Q;
    T(:,1)  =  (0:K-1)*Q;
    T(end,2) = n;
else
    T(1,1)  =  0; 
    T(1,2) = n;
    K = 1; 
end

% Find geometric pathways in time slices of the wavelet domain for faster
% computation. K is the number of slices and if K = 1, then the entire 
% wavelet domain is used at once. 

for k=1:K
    
    for i=1:length(Args.alphas)
        [x{i} y{i} xh{i} yh{i} narea{i}] = polydivide(sig(:,:,i),T(k,1),T(k,2),scale);
    end
    
    [xt yt xpatch ypatch at holetx holety] = createpathways(x, y, xh, yh,narea);
    
    if(k==1)
      anew = at;  
      xnew = xt; 
      ynew = yt; 
      xhnew = holetx; 
      yhnew = holety;
    else
      anew = vertcat(anew,at);  
      xnew = vertcat(xnew,xt);  
      ynew = vertcat(ynew,yt); 
      xhnew = vertcat(xhnew,holetx);  
      yhnew = vertcat(yhnew,holety); 
      
    end
    
    
end


if Args.MakeFigure
    

    Yticks = 2.^(fix(log2(min(period))):fix(log2(max(period))));
    
    if Args.BlackandWhite
        levels = [0 0.5 0.7 0.8 0.9 1];
       [x0 y0] = plot_cumareatest_results(anew, xnew, ynew, Args.alphac, 3, period,xhnew, yhnew, Args.Mother);

        cmap=[0 1;.5 .9;.8 .8;.9 .6;1 .5];
        cmap=interp1(cmap(:,1),cmap(:,2),(0:.1:1)');
        cmap=cmap(:,[1 1 1]);
        colormap(cmap)
        set(gca,'YLim',log2([min(period),max(period)]), ...
            'YDir','reverse', 'layer','top', ...
            'YTick',log2(Yticks(:)), ...
            'YTickLabel',num2str(Yticks'), ...
            'layer','top')
        ylabel('Period')
        hold on

        %phase plot
%         
%         aaa=angle(PWyx1x2);
%         aaa(Rsq<.5)=NaN;
%         %[xx,yy]=meshgrid(t(1:5:end),log2(period));
% 
%         phs_dt=round(length(t)/Args.ArrowDensity(1)); tidx=max(floor(phs_dt/2),1):phs_dt:length(t);
%         phs_dp=round(length(period)/Args.ArrowDensity(2)); pidx=max(floor(phs_dp/2),1):phs_dp:length(period);
%         phaseplot(t(tidx),log2(period(pidx)),aaa(pidx,tidx),Args.ArrowSize,Args.ArrowHeadSize);

      
        %suptitle([sTitle ' coherence']);
        %plot(t,log2(coi),'k','linewidth',2)
                tt=[t([1 1])-dt*.5;t;t([end end])+dt*.5];
        %hcoi=fill(tt,log2([period([end 1]) coi period([1 end])]));
        %hatching- modified by Ng and Kwok
        hcoi=fill(tt,log2([period([end 1]) coi period([1 end])]),'w');
  
        hatch(hcoi,45,[0 0 0]);
        hatch(hcoi,135,[0 0 0]);
        set(hcoi,'alphadatamapping','direct','facealpha',.5)
        plot(t,log2(coi),'color','black','linewidth',1.5)
        hold off
    else
        H=imagesc(t,log2(period),Rsq);%#ok
        %[c,H]=safecontourf(t,log2(period),Rsq,[0:.05:1]);
        %set(H,'linestyle','none')
        
        set(gca,'clim',[0 1])
        
        HCB=safecolorbar;%#ok
        
        set(gca,'YLim',log2([min(period),max(period)]), ...
            'YDir','reverse', 'layer','top', ...
            'YTick',log2(Yticks(:)), ...
            'YTickLabel',num2str(Yticks'), ...
            'layer','top')
        ylabel('Period')
        hold on

        %phase plot
%         
%         aaa=angle(PWyx1x2);
%         aaa(Rsq<.5)=NaN; %remove phase indication where Rsq is low
%         %[xx,yy]=meshgrid(t(1:5:end),log2(period));
% 
%         phs_dt=round(length(t)/Args.ArrowDensity(1)); tidx=max(floor(phs_dt/2),1):phs_dt:length(t);
%         phs_dp=round(length(period)/Args.ArrowDensity(2)); pidx=max(floor(phs_dp/2),1):phs_dp:length(period);
%         phaseplot(t(tidx),log2(period(pidx)),aaa(pidx,tidx),Args.ArrowSize,Args.ArrowHeadSize);

        [x0 y0] = plot_cumareatest_results(anew, xnew, ynew, Args.alphac, 3, period,xhnew, yhnew, Args.Mother);
       
       
        %suptitle([sTitle ' coherence']);
        tt=[t([1 1])-dt*.5;t;t([end end])+dt*.5];
        hcoi=fill(tt,log2([period([end 1]) coi period([1 end])]),'w');
        set(hcoi,'alphadatamapping','direct','facealpha',.5)
        hold off
    end
end