% demo
close all
clear all
%
% create time series
x1 = sin(.2*(1:1000)); % period of sinusoid = (2* pi)/0.2 = 31.0
x2 = sin(.1*(1:1000)); % period of sinusoid = (2* pi)/0.1 = 63.0
x3 =  sin(.3*(1:1000));% period of sinusoid = (2* pi)/0.3 = 21.0

xtime = x1 + x2 + x3; 

xtime = awgn(xtime,-5); % add white noise such that the noise level is greater than the signal level


% create wavelet power spectrum using the areawise significance test with
% significance level set to 0.05. Compare the results to that obtained
% from the geometric test appied at the 5% significance level.

figure(1)
subplot(2,1,1)
wt_areawise(xtime,'Mother','Morlet','alphac',0.05);
subplot(2,1,2)
wt_geo(xtime,'Mother','Morlet','alphag',0.95);



% create a null distribution using a different set of pointwise
% significance levels


h = waitbar(0,'Creating Null Distribution'); 
alphas = 0.90:0.02:.99; 
a0(1:length(alphas)+1) = NaN; 

for ii=1:5
    x = rednoise(300,0.5,1);
    [wave,period,scale,coi,sig anew] = wt_areawise(xtime,'Mother','Morlet','alphac',0.05,'alphas',alphas);
    a0 =  vertcat(a0,anew); 
    
    waitbar(ii/5,h);  
end

 close(h); 
 
a0(1,:) = [];
cumarea = nansum(a0,2); 

figure(2)
hist(cumarea); 



x = rednoise(200,.5,1);
y = rednoise(200,.5,1);
figure(3)
 wtc_areawise(x,y,'alphac',0.05);




 