function [u_r,v_r,w_r,angles] = natWindRot(u,v,w,t,thirdRotation,plotMe)
% function [u_r,v_r,w_r,angles] = natWindRot(u,v,w,t,thirdRotation,plotMe)
% Rotates wind vectors such that vavg=wavg=0 for a chunk of data.
% Routine has been taken from "Handbook of Micrometeorology" by Lee, Massman and Law.
% Designed for use with ECFluxToolBox.
%
% INPUTS:
% u,v,w: x,y and z wind vectors in the instrument coordinate
% t: time vector for winds.
% thirdRotation: flag to do the third rotation. 1 for yes, 0 for no (default).
% plotMe: flag for generating time series plot. default is 0 (no).
%
% OUTPUTS:
% u_r,v_r,w_r: wind vectors rotated into the natural wind coordinate.
%              u_r: horizontal wind speed in mean wind direction.
%              v_r: cross-wind speed
%              w_r: vertical wind speed
% angles: structure containing rotation angles (in degrees):
%   eta: rotation angle around the z1 axis
%   theta: rotation angle around the y1 axis
%   beta: rotation angle around x2 axis to make cross-wind momentum flux (w2'v2')bar = 0
%
% 20130915 GMW

%defaults
if nargin<6
    plotMe = 0;
end

if nargin<5
    thirdRotation = 0;
end

%Define some quantities
u1=u; v1=v; w1=w;
u1m=nanmean(u1); v1m=nanmean(v1); w1m=nanmean(w1);
u1m2=u1m.^2; v1m2=v1m.^2; w1m2=w1m.^2;
rms_uv=sqrt(u1m2+v1m2); rms_uvw=sqrt(u1m2+v1m2+w1m2);

%cosines and sines
CE = u1m./rms_uv;
SE = v1m./rms_uv;
CT = rms_uv./rms_uvw;
ST = w1m./rms_uvw;

%first two rotations
u2 = u1*CT*CE + v1*CT*SE + w1*ST;
v2 = v1*CE - u1*SE;
w2 = w1*CT - u1*ST*CE - v1*ST*SE;

%third rotation (optional)
v2p = v2-nanmean(v2); w2p = w2-nanmean(w2);
B = 0.5*atan(2*nanmean(v2p.*w2p)./(nanmean(v2p.^2)-nanmean(w2p.^2)));
CB = cos(B); SB = sin(B);
if thirdRotation
    v_r = v2*CB + w2*SB;
    w_r = w2*CB - v2*SB;
else
    v_r = v2;
    w_r = w2;
end
u_r = u2;

%rotation angles
angles.eta   = asin(SE)*180/pi;
angles.theta = asin(ST)*180/pi;
angles.beta  = B*180/pi;

%plot if desired
if plotMe
    o = ones(size(t));
    
    % U
    figure
    plot(t,u,'g-',...
        t,u_r,'c-',...
        t,nanmean(u)*o,'k--',...
        t,nanmean(u_r)*o,'b--')
    xlabel('Time')
    ylabel('U wind speed')
    legend('raw','rot','raw mean','rot mean')
    box on
    
    % V
    figure
    plot(t,v,'g-',...
        t,v_r,'c-',...
        t,nanmean(v)*o,'k--',...
        t,nanmean(v_r)*o,'b--')
    xlabel('Time')
    ylabel('V wind speed')
    legend('raw','rot','raw mean','rot mean')
    box on
    
    % W
    figure
    plot(t,w,'g-',...
        t,w_r,'c-',...
        t,nanmean(w)*o,'k--',...
        t,nanmean(w_r)*o,'b--')
    xlabel('Time')
    ylabel('W wind speed')
    legend('raw','rot','raw mean','rot mean')
    box on
    
end

