function [x y xh yh narea] = polydivide(sig,T1,T2,scale)

% Finds patches such that all time-coordinates are greater than or equal to T1
% and such that all time-coordinates are also less than or equal to T2

%Inputs:
% a matrix of significance corresponding to each wavelet coefficient
% T1 - minimum time-coordinate
% T2 - maximum time-coordinate
% scale - a vector of scales
%Outputs:
% x - a cell array of time-coordinates of patches
% y - a cell array of scale-coordinates of patches
% xh - a cell array of time-coordinates of holes
% yh - a cell array of scake-coordinates of holes
% narea - an array containing the normalized areas associated with the
% patches

[ncomp J Apatch convexity Anorm xpatch ypatch xhole yhole]= patch_geo(sig, scale);



x{1} = NaN;
y{1} = NaN;
xh{1} = NaN;
yh{1} = NaN;

narea(1) = NaN;


for j=1:length(xpatch)
    clear id idg idl idi
    id = find(xpatch{j}==T1);
    id2 = find(xpatch{j}==T2);
    
    idl = find(xpatch{j} < T2);
    idg = find(xpatch{j} > T1);
    idi = intersect(idl,idg);
    
    if(~isempty(id))||(~isempty(id2))
        
        y{end+1} = ypatch{j};
        x{end+1} = xpatch{j};
        narea(end+1) = Anorm(j);
        
    elseif(length(xpatch{j})==length(idl))&&(length(xpatch{j})==length(idg))
        
        narea(end+1) = Anorm(j);
        y{end+1} = ypatch{j};
        x{end+1} = xpatch{j};
        
    else
        
    end
    
    
end

for j=1:length(xhole)
    clear id idg idi idl
    
    id = find(xhole{j}==T1);
    id2 = find(xhole{j}==T2);
    
    idl = find(xhole{j} < T2);
    idg = find(xhole{j} > T1);
    idi = intersect(idl,idg);
    
    if(~isempty(id))||(~isempty(id2))
        
        yh{end+1} = yhole{j};
        xh{end+1} = xhole{j};
        
    elseif(length(xhole{j})==length(idl))&&(length(xhole{j})==length(idg))
        
        yh{end+1} = yhole{j};
        xh{end+1} = xhole{j};
        
    else
        
    end
    
    
end

x(1) = [];
y(1) = [];
xh(1)= [];
yh(1) = [];
narea(1) = [];





end

