function [xt yt xpatch ypatch at holetx holety] = createpathways(x,y,xhole,yhole,Acell)

%Desciption:
% Generates all geometric pathways in a wavelet spectra for a
% finite set of pointwise significance levels



%Inputs:
% x - A cell array containing cell arrays of time-coordinates of
% patches. x{1}, for example, contains the time-coordinates of
% patches at the highest pointwise significance level.

% y - A cell array containing cell arrays of y-coordinates of
% patches

% xhole - Cell array containing time-coordinates of holes

% yhole - Cell array containing y-coordinates of holes

% Acell - A cell array of normalized areas corresponding to the
% patches
%Outputs:

% xt - a MxN cell array containing the time-coordinates of all
% pathways. M denotes the number of pathways and N denotes the
% number of pointwise significance levels that were input into the
% wt_areawise routine. The default value of N is 9.

% yt - Same as xt but for the scale-coordinates of all pathways.

% at - A MxN matrix of normalized areas, where the rows correspond
% to the distinct geometric pathways and the columns refer to the
% significance level at which each of the pathway elements exist.
% The first column consists of the normalized areas of the
% largest elements of the M geometric pathways.

% holetx - cell array of time-coordinates for all holes at every
% pointwise significance level.

% holety - cell array of scale-coordinates for all holes at every
% pointwise significance level.

if(~isempty(xhole))
    holetx = xhole{1}';
    holety = yhole{1}';
else
    holetx = NaN;
    holety = NaN;
end

% start with largest pathway elements
xt = x{1}';
yt = y{1}';
at = Acell{1}';


% preallocate
L = length(x);
C = num2cell(nan(length(xt),L));
temp = nan(length(xt),L);
count = NaN;


xt = horzcat(xt,C);
yt = horzcat(yt,C);
at = horzcat(at,temp);


warning('off','all');
for j=2:L
    clear count
    
    
    xpatch = x{j}';
    ypatch = y{j}';
    Anorm = Acell{j};
    
    
    holetx = vertcat(holetx,xhole{j}');
    holety = vertcat(holety,yhole{j}');
    
    [n1 m1] = size(xt);
    count = zeros(1,n1);
    n2 = length(xpatch);
    
    % generate combination of vectors to avoid nested for loops
    Z = combvec(1:n1,1:n2)';
    ix = Z(:,1);
    iy = Z(:,2);
    
    for jj=1:length(ix)
        % rule out impossible intersections
        [I] = check_intersection(xt{ix(jj),j-1},yt{ix(jj),j-1},xpatch{iy(jj)},ypatch{iy(jj)});
        
        if(I==0)
            xi = [];
        else
            [xi yi] =  polybool('intersection',xt{ix(jj),j-1},yt{ix(jj),j-1},xpatch{iy(jj)},ypatch{iy(jj)});
        end
        
        if(~isempty(xi))
            
            if(count(ix(jj))==0)
                xt{ix(jj),j} = xpatch{iy(jj)};
                yt{ix(jj),j} = ypatch{iy(jj)};
                
                at(ix(jj),j) = Anorm(iy(jj));
                
                
                count(ix(jj)) =  count(ix(jj)) + 1;
                
            else
                %new geometric pathway. Add to bottom of xt, yt, and at arrays
                xt = vertcat(xt, xt(ix(jj),:));
                yt = vertcat(yt, yt(ix(jj),:));
                at = vertcat(at, at(ix(jj),:));
                
                
                xt{end,j} = xpatch{iy(jj)};
                yt{end,j} = ypatch{iy(jj)};
                at(end,j) = Anorm(iy(jj));
                
                count(ix(jj)) =  count(ix(jj)) + 1;
                
            end
            
        end
        
        
        
    end
    
    
end
 

end

