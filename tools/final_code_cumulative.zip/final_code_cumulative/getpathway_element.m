function [x0 y0 xcum ycum csum] = getpathway_element(at, xt, yt, pvals, critp)


%Description:
          % Finds the largest elements of each of the M pathways such that
          % the p-values are less than the significance level of the test. 
%Inputs:
          % xt - a MxN cell array containing the time-coordinates of all 
          % pathways. M denotes the number of pathways and N denotes the 
          % number of pointwise significance levels that were input into the 
          % wt_areawise routine. The default value of N is 9. 
          
          % yt - Same as xt but for the scale-coordinates of all pathways.
          
          % at - A MxN matrix of normalized areas, where the rows correspond 
          % to the distinct geometric pathways and the columns refer to the 
          % pointwise significance level at which each of the pathway elements 
          % exist. The first column consists of the normalized
          % areas of the largest elements of the M geometric pathways.
          
          % pvals - A MxN matrix of p-values, where the rows correspond to 
          % distinct geometric pathways and the columns refer to the
          % pointwise significance level at which each of the pathway 
          % elements exist. The first columns consists of the p-values of 
          % the largest elements of the M geometric pathways.

          % critp - the significance level of the test. The default is 0.05. 
%Outputs:
          % x0 and x0 are the union of all pathway elements whose pvals are
          % less than critp
     
          % xcum - cell array of time-coordinates of significant geometric
          % pathways
         
          % ycum - cell array of scale-coordinates of significant geometric
          % pathways
         
          % csum - A MxN array of cumulative sums associated with the array
          % at. The cumulative sum is calculated such that the largest 
          % element of the pathway has the smallest sum. 
         

 x0 = NaN;
 y0 = NaN; 
 at(isnan(at)) = 0;
 csum = cumsum(at,2);
 
 % find the union of the cumulative significance patches
 
 [ipy ipx] = find(pvals<critp); 

 for z=1:length(ipy)
     
     if(~isnan(yt{ipy(z),ipx(z)}))
         
         [dx dy] =   polybool('union',x0, y0, xt{ipy(z),ipx(z)}, yt{ipy(z),ipx(z)});
         x0 = dx;
         y0 = dy;
         
     end
 end
 
 %break up union into cell array
 [xcum ycum] = polysplit(x0 , y0);

 
end

